#pragma once

#include <stdio.h>

int getName(FILE *in, char *name, int limit);
int getId(FILE *in, char *id, int limit);
