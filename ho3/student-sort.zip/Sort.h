#pragma once

#include "Person.h"

void sortByName(Person *ar, int size);
void sortByAge(Person *ar, int size);